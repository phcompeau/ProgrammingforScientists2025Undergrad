import random  # for generating random numbers
from election_io import *  # for reading from files

def main() :
	print("Let's simulate an election!")
